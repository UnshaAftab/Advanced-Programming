import RegisterModal from './RegisterModal';

export default RegisterModal;
