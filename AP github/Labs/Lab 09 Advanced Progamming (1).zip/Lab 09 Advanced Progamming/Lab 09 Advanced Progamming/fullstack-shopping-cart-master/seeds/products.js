const mongoose = require('mongoose');
const Product = require('../models/Product');

const products = [
  {
    info: {
      name: 'Huawei Mate 10 Pro',
      dimensions: '154.2 x 74.5 x 7.9 mm',
      weight: '178 g',
      displayType: 'AMOLED capacitive touchscreen, 16M colors',
      displaySize: '6.0"',
      displayResolution: '1080 x 1920 pixels',
      os: 'Android 8.0 (Oreo)',
      cpu: 'Octa-core (4x2.4 GHz Cortex-A73 & 4x1.8 GHz Cortex-A53)',
      internalMemory: '128 GB',
      ram: '6 GB',
      camera: 'Dual: 12 MP (f/1.6, 27mm, OIS) +20 MP (f/1.6, 27mm)',
      batery: 'Non-removable Li-Po 4000 mAh battery',
      color: 'Titanium Gray',
      price: 800,
      photo: '/img/huawei_mate_10_pro.jpg'
    },
    tags: {
      priceRange: '500-750',
      brand: 'samsung',
      color: 'black',
      os: 'android',
      internalMemory: '64',
      ram: '4',
      displaySize: '5.8',
      displayResolution: '1440x2960',
      camera: '12',
      cpu: 'octa_core'
    }
  }
];

const seedProducts = () => {
  Product.remove({}, (err) => {
    if(err) {
      console.log(err);
    }
    console.log('PRODUCTS REMOVED');
    products.forEach((product) => {
      Product.create(product, (err, createdProduct) => {
        if(err) {
          console.log(err);
        } else {
          console.log('PRODUCT CREATED');
          createdProduct.save();
        }
      })
    })
  })
}

module.exports = seedProducts;